from django.apps import AppConfig


class RegLoginLogoutAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reg_login_logout_app'
